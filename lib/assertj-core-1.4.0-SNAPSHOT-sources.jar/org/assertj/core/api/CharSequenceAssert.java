/*
 * Created on May 7, 2013
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 * 
 * Copyright @2010-2013 the original author or authors.
 */
package org.assertj.core.api;

/**
 * Assertion methods for {@code CharSequence}s.
 * <p>
 * To create a new instance of this class, invoke <code>{@link Assertions#assertThat(CharSequence)}</code>.
 * </p>
 * 
 * @author Mikhail Mazursky
 */
public class CharSequenceAssert extends AbstractCharSequenceAssert<CharSequenceAssert, CharSequence> {

  protected CharSequenceAssert(CharSequence actual) {
    super(actual, CharSequenceAssert.class);
  }
}
